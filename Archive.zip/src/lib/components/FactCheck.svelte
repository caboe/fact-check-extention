<!-- src/components/FactCheck.svelte -->
<script lang="ts">
	import { Accordion } from '@skeletonlabs/skeleton'
	import view from '../state/view.svelte'
	import checkFact from '../util/checkFact.svelte'
	import Connection from './steps/Connection.svelte'
	import Response from './steps/Response.svelte'
	import Selected from './steps/Selected.svelte'
	import unifiedStorage from '../util/unifiedStorage.svelte'
	import endpoints from '../state/endpoints.svelte'
	import apiRequest from '../state/apiRequest.svelte'
	import L from '../state/L.svelte'
</script>

<div class="p-1">
	<Accordion autocollapse spacing="space-y-4">
		<Selected open={view.step === 0} on:click={() => (view.step = 0)} />
		<Connection open={view.step === 1} on:click={() => (view.step = 1)} {checkFact} />
		<Response open={view.step === 2} on:click={() => (view.step = 2)} />
	</Accordion>

	{#if view.step !== 2}
		<div class="mt-4 px-4">
			<div class="mb-4 flex flex-col items-center justify-between gap-2">
				<input type="range" min="3" max="500" bind:value={apiRequest.value.range} class="w-full" />
				<div class="text-sm">{L.responseLength({ responseLength: apiRequest.value.range })}</div>
			</div>
			<button
				class="variant-filled-primary btn w-full"
				onclick={checkFact}
				disabled={!unifiedStorage.value.selectedContent || !endpoints.value.selected}
				data-testid="fact-check-btn"
			>
				{#if apiRequest.value.state === 'LOADING'}
					{L.checkingProgress()}
				{:else if apiRequest.value.state === 'THINKING'}
					{L.thinking()}
				{:else if apiRequest.value.state === 'STREAMING'}
					{L.checkingProgress()}
				{:else}
					{L.apiCta()}
				{/if}
			</button>
		</div>
	{/if}
</div>
