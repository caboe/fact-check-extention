class View {
	step = $state(0)
	showAddEndpointForm = $state(false)
	showEditEndpointForm = $state(false)
	showRoleConfig = $state(false)
}

const view = new View()

export default view
